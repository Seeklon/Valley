# IGNIS — modèle chaleur/fumée, adaptation ventilation

Poids entraînés sur GPU le 15 novembre 2026. Même U-Net 3D : 379 046 paramètres,
dont 376 834 entraînables. Ce paquet contient le modèle et son code d'inférence,
avec un exemple de scène ; il ne contient pas les gros replays du site.

## Exécuter le modèle

Prérequis : Python 3.11 ou 3.12, dans un environnement dédié. Depuis ce dossier :

```text
python -m pip install -r model/requirements.txt
python model/predict.py --output prediction.npz
```

L'inférence fonctionne sur CPU et ne lance aucune simulation FDS ni entraînement.
Le script refuse d'écraser un résultat existant. Pour une scène annotée compatible :

```text
python model/predict.py --scene scene.json --config config.json --output nouvelle-prediction.npz
```

Les formats attendus sont illustrés dans `model/example/`. Un GLB seul ne suffit
pas : il faut géométrie physique, matériaux, source électrique et ventilation.
L'exemple vient de la première campagne ; ce n'est pas un test indépendant.

Le NPZ contient les instants 0, 5, 10, 20 et 30 s, les positions des 1 536 sondes,
les scores chaleur/fumée, les classes seuillées et les masques de validité.
Les seuils sélectionnés restent ceux de `model/frozen-selection.json`.

## Résultats et portée

Sur 54 nouveaux scénarios synthétiques réservés : F1 chaleur 0,553 et fumée
0,579 ; rappels 0,601 et 0,594. Comparaisons et limites sont dans
`docs/ISS_POC_VENT_MODEL.md`. La chaleur produit davantage de faux positifs
en valeur absolue et régresse légèrement sur les racks centraux.

Le modèle prédit des conséquences conditionnelles à une source imposée. Ses
scores ne sont ni une température, ni une concentration de fumée, ni une
probabilité de départ de feu. Six familles de géométries simplifiées, sans
validation expérimentale NASA ni garantie sur une scène arbitraire.

La vue de développement relit les prédictions enregistrées :
https://desktop-m4hkr86.tail609f26.ts.net:8444/#iss

`artifact.json` identifie les poids et les empreintes des fichiers livrés.
