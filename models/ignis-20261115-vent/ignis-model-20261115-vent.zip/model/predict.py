"""Run actual CPU inference from scene and conditions; never launches FDS."""
import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / "backend"))
from iss_poc_model import ISSPredictor

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--scene", type=Path, default=root / "example/scene.json")
parser.add_argument("--config", type=Path, default=root / "example/config.json")
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
if args.output.exists():
    raise FileExistsError("Choose a new output file")
torch.set_num_threads(4)
metadata = json.loads((root / "report.json").read_bytes())["model"]
model = ISSPredictor(root / "weights.pt", expected_sha256=metadata["weights_sha256"])
scene = json.loads(args.scene.read_bytes())
config = json.loads(args.config.read_bytes())
result = model.predict_scene(scene, config, times=[0, 5, 10, 20, 30])
args.output.parent.mkdir(parents=True, exist_ok=True)
with args.output.open("xb") as stream:
    np.savez_compressed(stream, **{k: result[k] for k in
        ("time_s", "sample_positions_m", "scores", "predicted_mask", "valid_mask")})
print(json.dumps({"weights_sha256": model.weights_sha256,
                  "shape": list(result["scores"].shape),
                  "outputs": result["output_channels"],
                  "semantics": result["score_semantics"],
                  "output": str(args.output)}, indent=2))
